from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth.views import LoginView,LogoutView


#-------------FOR ADMIN RELATED URLS
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',hospital.home_view,name=''),


    path('aboutus', hospital.aboutus_view),
    path('contactus', hospital.contactus_view),


    path('adminclick', hospital.adminclick_view),
    path('doctorclick', hospital.doctorclick_view),
    path('patientclick', hospital.patientclick_view),

    path('adminsignup', hospital.admin_signup_view),
    path('doctorsignup', hospital.doctor_signup_view,name='doctorsignup'),
    path('patientsignup', hospital.patient_signup_view),
    
    path('adminlogin', LoginView.as_view(template_name='hospital/adminlogin.html')),
    path('doctorlogin', LoginView.as_view(template_name='hospital/doctorlogin.html')),
    path('patientlogin', LoginView.as_view(template_name='hospital/patientlogin.html')),


    path('afterlogin', hospital.afterlogin_view,name='afterlogin'),
    path('logout', LogoutView.as_view(template_name='hospital/index.html'),name='logout'),


    path('admin-dashboard', hospital.admin_dashboard_view,name='admin-dashboard'),

    path('admin-doctor', hospital.admin_doctor_view,name='admin-doctor'),
    path('admin-view-doctor', hospital.admin_view_doctor_view,name='admin-view-doctor'),
    path('delete-doctor-from-hospital/<int:pk>', hospital.delete_doctor_from_hospital_view,name='delete-doctor-from-hospital'),
    path('update-doctor/<int:pk>', hospital.update_doctor_view,name='update-doctor'),
    path('admin-add-doctor', hospital.admin_add_doctor_view,name='admin-add-doctor'),
    path('admin-approve-doctor', hospital.admin_approve_doctor_view,name='admin-approve-doctor'),
    path('approve-doctor/<int:pk>', hospital.approve_doctor_view,name='approve-doctor'),
    path('reject-doctor/<int:pk>', hospital.reject_doctor_view,name='reject-doctor'),
    path('admin-view-doctor-specialisation',hospital.admin_view_doctor_specialisation_view,name='admin-view-doctor-specialisation'),


    path('admin-patient', hospital.admin_patient_view,name='admin-patient'),
    path('admin-view-patient', hospital.admin_view_patient_view,name='admin-view-patient'),
    path('delete-patient-from-hospital/<int:pk>', hospital.delete_patient_from_hospital_view,name='delete-patient-from-hospital'),
    path('update-patient/<int:pk>', hospital.update_patient_view,name='update-patient'),
    path('admin-add-patient', hospital.admin_add_patient_view,name='admin-add-patient'),
    path('admin-approve-patient', hospital.admin_approve_patient_view,name='admin-approve-patient'),
    path('approve-patient/<int:pk>', hospital.approve_patient_view,name='approve-patient'),
    path('reject-patient/<int:pk>', hospital.reject_patient_view,name='reject-patient'),
    path('admin-discharge-patient', hospital.admin_discharge_patient_view,name='admin-discharge-patient'),
    path('discharge-patient/<int:pk>', hospital.discharge_patient_view,name='discharge-patient'),
    path('download-pdf/<int:pk>', hospital.download_pdf_view,name='download-pdf'),


    path('admin-appointment', hospital.admin_appointment_view,name='admin-appointment'),
    path('admin-view-appointment', hospital.admin_view_appointment_view,name='admin-view-appointment'),
    path('admin-add-appointment', hospital.admin_add_appointment_view,name='admin-add-appointment'),
    path('admin-approve-appointment', hospital.admin_approve_appointment_view,name='admin-approve-appointment'),
    path('approve-appointment/<int:pk>', hospital.approve_appointment_view,name='approve-appointment'),
    path('reject-appointment/<int:pk>', hospital.reject_appointment_view,name='reject-appointment'),
]


#---------FOR DOCTOR RELATED URLS-------------------------------------
urlpatterns +=[
    path('doctor-dashboard', hospital.doctor_dashboard_view,name='doctor-dashboard'),

    path('doctor-patient', hospital.doctor_patient_view,name='doctor-patient'),
    path('doctor-view-patient', hospital.doctor_view_patient_view,name='doctor-view-patient'),
    path('doctor-view-discharge-patient',hospital.doctor_view_discharge_patient_view,name='doctor-view-discharge-patient'),

    path('doctor-appointment', hospital.doctor_appointment_view,name='doctor-appointment'),
    path('doctor-view-appointment', hospital.doctor_view_appointment_view,name='doctor-view-appointment'),
    path('doctor-delete-appointment',hospital.doctor_delete_appointment_view,name='doctor-delete-appointment'),
    path('delete-appointment/<int:pk>', hospital.delete_appointment_view,name='delete-appointment'),
]




#---------FOR PATIENT RELATED URLS-------------------------------------
urlpatterns +=[

    path('patient-dashboard', hospital.patient_dashboard_view,name='patient-dashboard'),
    path('patient-appointment', hospital.patient_appointment_view,name='patient-appointment'),
    path('patient-book-appointment', hospital.patient_book_appointment_view,name='patient-book-appointment'),
    path('patient-view-appointment', hospital.patient_view_appointment_view,name='patient-view-appointment'),
    path('patient-discharge', hospital.patient_discharge_view,name='patient-discharge'),

]

